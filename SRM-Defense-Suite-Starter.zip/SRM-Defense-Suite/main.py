print('SRM Defense Suite Initialized')
